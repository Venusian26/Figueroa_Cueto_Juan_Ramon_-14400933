package com.example.venusian.juegogato;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity  {
int contador;
boolean turno;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//Relacionamos lo Botones con su id
        final Button btn1=(Button)findViewById(R.id.btn1);
        final Button btn2=(Button)findViewById(R.id.btn2);
        final Button btn3=(Button)findViewById(R.id.btn3);
        final Button btn4=(Button)findViewById(R.id.btn4);
        final Button btn5=(Button)findViewById(R.id.btn5);
        final Button btn6=(Button)findViewById(R.id.btn6);
        final Button btn7=(Button)findViewById(R.id.btn7);
        final Button btn8=(Button)findViewById(R.id.btn8);
        final Button btn9=(Button)findViewById(R.id.btn9);
        final Button btnNuevo=(Button)findViewById(R.id.btnNuevo);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

              contador++;
            MainActivity.Logica(btn1,contador);
            }//evento

        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                contador++;
                MainActivity.Logica(btn2,contador);
            }//evento

        });
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                contador++;
                MainActivity.Logica(btn3,contador);
            }//evento

        });
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                contador++;
                MainActivity.Logica(btn4,contador);
            }//evento

        });
        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                contador++;
                MainActivity.Logica(btn5,contador);
            }//eventos

        });
        btn6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                contador++;
                MainActivity.Logica(btn6,contador);
            }//evento

        });
        btn7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                contador++;
                MainActivity.Logica(btn7,contador);
            }//evento

        });
        btn8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                contador++;
                MainActivity.Logica(btn8,contador);
            }//evento

        });
        btn9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                contador++;
                MainActivity.Logica(btn9,contador);
            }//evento

        });
        btnNuevo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                btn1.setText("");
                btn2.setText("");
                btn3.setText("");
                btn4.setText("");
                btn5.setText("");
                btn6.setText("");
                btn7.setText("");
                btn8.setText("");
                btn9.setText("");
            }//evento

        });
    }
    public static void Logica (Button boton,int contador){

        if((contador%2)==0){
            boton.setText("X");
        }else{
            boton.setText("O");

        }//else

    }
}
